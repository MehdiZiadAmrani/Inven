package com.joseplanes.inven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InvenApplicationTests {

	@Test
	void contextLoads() {
	}

}
